#!/usr/bin/env python  
#-*- coding: utf-8 -*-
import socket
import urllib.request
import urllib.error
import os
import shutil
import configparser
import platform
from git import Repo

def http_validate(target_url):
    try:
        response = urllib.request.urlopen(target_url, timeout=30)
        return True
    except urllib.error.URLError as e:
        return False

if __name__ == "__main__":

    urlBaidu = 'https://www.baidu.com'
    url = 'https://github.com/NEXTBlockChain/GlobalSettings.git'

    to_path = ''
    config_ini = ''
    python_bin=''

    sysstr = platform.system()    
    if(sysstr == "Windows"):
        print("Init windows Settings:")
        to_path = 'D:\\TestGit\\GlobalSettings'
        config_ini = 'D:\\TestGit\\GlobalSettings\\settings.ini'
        python_bin = 'python '
    elif(sysstr == "Linux"):
        print("Init linux Settings:")
        to_path = '/home/tmp/GlobalSettings'
        config_ini ='/home/tmp/GlobalSettings/settings.ini'
        python_bin = '/usr/bin/python '
    

    if os.path.exists(to_path):
        shutil.rmtree(to_path)

    if http_validate(urlBaidu):    
        clone_repo = Repo.clone_from(
            url, to_path)
        print("Update Successful!!!")
    else:
        print("Update Error!!!")
    
    config = configparser.ConfigParser()
    config.read(config_ini)
    servicestart = config["AutoRunFiles"]["service.start"]
    ZipFiles = config["AutoRunFiles"]["ZipFiles"]
    AutoRun = config["AutoRunFiles"]["AutoRun"]
    print("service.start is:" + servicestart)
    print("ZipFiles is:" + ZipFiles)
    print("AutoRun is:" + AutoRun)

    if (sysstr == "Linux"):
        print("Run in Linux: " + python_bin + AutoRun)
        val = os.system(python_bin + AutoRun)
    else:
        print("Run in Windows: " + python_bin + AutoRun)


