#!/usr/bin/env python  
#-*- coding: utf-8 -*-
import socket
import urllib.request
import urllib.error
import os
import shutil
import configparser
import platform
from git import Repo

if __name__ == "__main__":
	print("5 minutes!!!")